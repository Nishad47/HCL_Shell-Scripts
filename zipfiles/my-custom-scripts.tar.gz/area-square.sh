#!/bin/bash
: 'Finding the area 
of a square'

a=4
((area=$a*$a))

echo "area of a square with side = $a is :" $area
