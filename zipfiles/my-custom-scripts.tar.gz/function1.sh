#!/bin/bash

function welcome()
{
	echo -n "Hello, "
	echo "$1"
}
welcome Nishad


