#!/bin/bash

#str="Welcome to shell programming"
echo -ne "Enter any string : \t"
read str
echo "Length of str is ${#str}"
