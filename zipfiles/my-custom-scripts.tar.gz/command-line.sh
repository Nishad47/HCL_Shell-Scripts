#!/bin/bash
echo "Total arguments : $#"
echo "File name : $0"
echo "1st argument : $1"
echo "2nd argument : $2"
