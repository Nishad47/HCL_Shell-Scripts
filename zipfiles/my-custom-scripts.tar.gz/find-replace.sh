#!/bin/bash

str="Example of bash scripting : Path os the bash is /bin/bash"
echo ${str//bash/shell}

