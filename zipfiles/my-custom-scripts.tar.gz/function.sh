#!/bin/bash
#This is an example of function

function f1()
{ 
	echo "I like bash programming"
}
f1
