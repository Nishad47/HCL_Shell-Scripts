#!/bin/bash
#Substring example

str="Shell scripting is very interesting process"
substr=${str:6:9}
echo $substr
