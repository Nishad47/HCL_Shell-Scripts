#!/bin/bash

function rectangle-area()
{
area=$(($1 * $2))
echo "area : $area"
}

rectangle-area 10 20

