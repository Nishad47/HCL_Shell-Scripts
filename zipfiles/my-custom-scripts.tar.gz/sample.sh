#!/bni/bash

str="Shell Scripting"
echo ${str:1:2}
