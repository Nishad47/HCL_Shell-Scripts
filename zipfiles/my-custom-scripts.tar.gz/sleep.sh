#!/bin/bash

echo "Wait for 5 seconds"
#sleep 5
#echo "Completed"

for (( i=1; i<=10; i++ ))
do
        echo $i
	sleep 2
done
