#!/bin/bash

n=1
    if [ $n -lt 10 ];
    then
	    echo "It is a single digit number"
    else
	    echo "It is not a single digit number"
    fi

