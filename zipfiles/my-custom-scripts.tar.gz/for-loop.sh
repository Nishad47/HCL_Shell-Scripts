#!/bin/bash
#For-loop example

for (( counter=100; counter>0; counter-- ))
do
	echo -n "$counter "
done
echo
