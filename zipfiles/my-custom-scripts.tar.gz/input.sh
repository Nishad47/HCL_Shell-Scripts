#!/bin/bash

echo "Enter your name"
read name
echo "Welcome $name to shell scripting"
